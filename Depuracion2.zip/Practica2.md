# Práctica 2 - Entornos de Desarrollo    <img src=".\capturas\logo_instituto\mz.png" alt="mz" width="70"/>

**0. Importar el projecte en INTELLIJ.**

<img src=".\capturas\1.png" alt="imagen1"/>

**1. Explicad QUÈ FA EL MÈTODE MAIN.**

> El método Main es el punto de entrada de un programa ejecutable; es donde se inicia y finaliza el control del programa

**2. Posad un punt de ruptura (breakpoint) en la línia 27 del mètode main de la classe Principal i esbrineu els valors de les variables velocitat_nueva1, velocitat_nueva2 i velocitat_nueva3. Esbrineu també quines dades tenen en els seus paràmetres els cotxes amb variables c,c2 i c3.**

* BREACKPOINT :

<img src=".\capturas\punto27.png" alt="imagen1"/>

* VALORES INICIALES:

<img src=".\capturas\valores_iniciales.png" alt="imagen1"/>

* VALORES FINALES:

<img src=".\capturas\valores_finales.png" alt="imagen1"/>

**3. Posad un punt de ruptura (breakpoint) en la línia 46 del mètode main de la classe Principal i esbrineu els valors de les variables velocitat_nueva1, velocitat_nueva2 i velocitat_nueva3. Esbrineu també quines dades tenen en els seus paràmetres els cotxes amb variables c,c2 i c3.**

* BREACKPOINT :

<img src=".\capturas\punto46.png" alt="imagen1"/>

* VALORES INICIALES:

<img src=".\capturas\valores_iniciales46.png" alt="imagen1"/>

* ENTRANDO A LA FUNCIÓN CON LA TECLA F7:

<img src=".\capturas\funcion.png" alt="imagen1"/>

* VALORES FINALES:

<img src=".\capturas\valores_finales46.png" alt="imagen1"/>
